exports.up = function(knex) {
  return knex.schema
    .createTable('clientes', function(table) {
      table.increments('id');
      table.string('nome').notNullable();
      table.string('endereco').notNullable();
      table.int('telefone').notNullable();
    })
};

exports.down = function(knex) {
  return knex.schema
    .dropTable('clientes');
};
