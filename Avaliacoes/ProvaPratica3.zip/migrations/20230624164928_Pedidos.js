exports.up = function(knex) {
  return knex.schema
    .createTable('pedidos', function(table) {
      table.increments('id');
      table.string('data').notNullable();
      table.string('itens').notNullable();
   
    })
};

exports.down = function(knex) {
  return knex.schema
    .dropTable('pedidos');
};
