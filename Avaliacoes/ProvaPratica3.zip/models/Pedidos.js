const knex = require('knex');
const database = knex({
  client: 'sqlite3',
  connection: {
    filename: './dev.sqlite3'
  }
});

class Pedido {
  static async fazerPedido(Pedido) {
    try {
      const [id] = await database('pedidos').insert(Pedido);
      console.log('Pedido realizado!');
      console.log('ID do seu pedido:', id)
    } catch (error) {
      console.error('Erro ao realizar pedido:', error);
    } finally {
      database.destroy();
    }
  }

  static async atualizarPedido(id, Pedido) {
    try {
      const result = await database('pedidos').where({ id }).update(Pedido);
      console.log('Pedido atualizado:', result);
    } catch (error) {
      console.error('Erro ao atualizar pedido:', error);
    } finally {
      database.destroy();
    }
  }

  static async verPedido(id) {
    try {
      const pedido = await database('pedidos').where({ id }).first();
      console.log('Pedido encontrado:', Pedido);
    } catch (error) {
      console.error('Erro ao tentar encontrar pedido:', error);
    } finally {
      database.destroy();
    }
  }

  static async excluirPedido(id) {
    try {
      const result = await database('pedidos').where({ id }).del();
      console.log('Pedido excluído:', result);
    } catch (error) {
      console.error('Erro ao excluir pedido:', error);
    } finally {
      database.destroy();
    }
  }
}

module.exports = Pedido;
 