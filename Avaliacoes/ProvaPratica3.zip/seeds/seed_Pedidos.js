exports.seed = function(knex, Promise) {
  return knex('pedidos').del()
    .then(function () {
      return knex('pedidos').insert([
        {data: '12/06/23', itens: 'Shampoo, Secador'},
        {data: '13/06/23', itens: 'Cola de isopor, Tesoura'}
      ]);
    });
};