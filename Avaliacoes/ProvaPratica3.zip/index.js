const Cliente = require('./models/Clientes.js');
const Pedido = require('./models/Pedidos.js');


const Cliente1 = {
  nome: 'Maria',
  endereco: 'Rua do Pocinho, 365',
  telefone : 987360438
};

const Pedido1 = {
  data: '23/04/23',
  itens: 'Tinta'
};

Cliente.criarCliente(Cliente1);
Cliente.obterCliente(3);
Pedido.fazerPedido(Pedido1);
Pedido.verPedido(1);