exports.seed = function(knex, Promise) {
  return knex('clientes').del()
    .then(function () {
      return knex('clientes').insert([
        {nome: 'Cliente1', endereco:'Null', telefone: 997653421},
        {nome: 'Cliente2', endereco:'Null2', telefone: 995673851}
      ]);
    });
};