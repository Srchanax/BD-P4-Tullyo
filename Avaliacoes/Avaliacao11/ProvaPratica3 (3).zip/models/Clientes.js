const knex = require('knex');
const database = knex({
  client: 'sqlite3',
  connection: {
    filename: './dev.sqlite3'
  }
});

class Cliente {
  static async criarCliente(Cliente) {
    try {
      const [id] = await database('clientes').insert(Cliente);
      console.log('Cliente cadastrado com ID:', id);
    } catch (error) {
      console.error('Erro ao cadastrar cliente:', error);
    } finally {
      database.destroy();
    }
  }

  static async atualizarCliente(id, Cliente) {
    try {
      const result = await database('clientes').where({ id }).update(Cliente);
      console.log('Cliente atualizado:', result);
    } catch (error) {
      console.error('Erro ao atualizar cliente:', error);
    } finally {
      database.destroy();
    }
  }

  static async obterCliente(id) {
    try {
      const cliente = await database('clientes').where({ id }).first();
      console.log('Cliente encontrado:', Cliente);
    } catch (error) {
      console.error('Erro ao obter cliente:', error);
    } finally {
      database.destroy();
    }
  }

  static async excluirCliente(id) {
    try {
      const result = await database('clientes').where({ id }).del();
      console.log('Cliente excluído:', result);
    } catch (error) {
      console.error('Erro ao excluir cliente:', error);
    } finally {
      database.destroy();
    }
  }
}

module.exports = Cliente;
 